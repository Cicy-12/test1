# Knowledge-graphs
The raw datas is used to construct the surving and remote sensing knowledge graph.
